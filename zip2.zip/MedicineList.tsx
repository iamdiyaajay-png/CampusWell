import { useMedicines } from "@/hooks/use-medicines";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Package, Factory } from "lucide-react";
import { motion } from "framer-motion";

export function MedicineList() {
  const { data: medicines, isLoading } = useMedicines();

  // Only show approved medicines to the public
  const approvedMedicines = medicines?.filter(m => m.status === 'approved') || [];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-48 rounded-xl bg-muted/50 animate-pulse" />
        ))}
      </div>
    );
  }

  if (approvedMedicines.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/30 rounded-2xl border border-dashed">
        <Package className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
        <h3 className="text-lg font-medium text-slate-900">No medicines available yet</h3>
        <p className="text-muted-foreground">Be the first to donate!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {approvedMedicines.map((medicine, index) => (
        <motion.div
          key={medicine.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-primary/10">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-display font-bold text-lg text-slate-900 line-clamp-1">
                    {medicine.name}
                  </h3>
                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                    <Factory className="w-3 h-3 mr-1" />
                    {medicine.manufacturer}
                  </div>
                </div>
                <Badge variant="outline" className="text-primary border-primary/20 bg-primary/5">
                  Available
                </Badge>
              </div>
              
              <div className="space-y-3 pt-2 border-t border-dashed">
                <div className="flex items-center text-sm">
                  <Package className="w-4 h-4 mr-2 text-primary" />
                  <span className="font-medium mr-2">Qty:</span> {medicine.quantity}
                </div>
                <div className="flex items-center text-sm">
                  <Calendar className="w-4 h-4 mr-2 text-destructive/60" />
                  <span className="font-medium mr-2">Expires:</span> {medicine.expiryDate}
                </div>
                {medicine.notes && (
                  <p className="text-xs text-muted-foreground bg-muted p-2 rounded mt-2">
                    "{medicine.notes}"
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
