import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Pill, LayoutDashboard, LogIn, LogOut, HeartHandshake } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
              <HeartHandshake className="w-6 h-6 text-primary" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-slate-900">
              Medi<span className="text-primary">Donate</span>
            </span>
          </div>
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/donate">
            <Button 
              variant={isActive("/donate") ? "default" : "ghost"}
              className={isActive("/donate") ? "bg-primary text-primary-foreground" : ""}
            >
              <Pill className="w-4 h-4 mr-2" />
              Donate Medicine
            </Button>
          </Link>

          {user ? (
            <>
              <Link href="/admin">
                <Button 
                  variant={isActive("/admin") ? "default" : "ghost"}
                  className={isActive("/admin") ? "bg-primary text-primary-foreground" : ""}
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Admin
                </Button>
              </Link>
              <div className="h-6 w-px bg-border mx-2" />
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium hidden md:block text-muted-foreground">
                  {user.firstName || user.username}
                </span>
                <Button variant="outline" size="sm" onClick={() => logout()}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </>
          ) : (
            <a href="/api/login">
              <Button variant="default" className="shadow-lg shadow-primary/20">
                <LogIn className="w-4 h-4 mr-2" />
                Admin Login
              </Button>
            </a>
          )}
        </div>
      </div>
    </nav>
  );
}
